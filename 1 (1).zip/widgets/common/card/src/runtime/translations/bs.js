define({
  _layout_REGULAR_label: 'Regularno',
  _layout_HOVER_label: 'Držanje iznad',
  applyTo: 'Primjeni na {status}',
  isolate: 'Izoliraj',
  linkedToAnd: 'Povezano na {where1} i {where2}',
  linkedTo: 'Povezano na {where}',
  placeHolderTip: 'Odaberite karticu predloška.',
  showSelected: 'Prikaži odabir',
  _widgetLabel: 'Kartica',
});