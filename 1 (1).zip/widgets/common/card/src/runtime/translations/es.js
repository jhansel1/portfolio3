define({
  _layout_REGULAR_label: 'Regular',
  _layout_HOVER_label: 'Pasar el cursor',
  applyTo: 'Aplicar a {status}',
  isolate: 'Aislar',
  linkedToAnd: 'Vinculado a {where1} y {where2}',
  linkedTo: 'Vinculado a {where}',
  placeHolderTip: 'Seleccione una plantilla de tarjeta.',
  showSelected: 'Mostrar selección',
  _widgetLabel: 'Tarjeta',
});