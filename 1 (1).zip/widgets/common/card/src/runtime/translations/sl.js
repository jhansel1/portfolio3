define({
  _layout_REGULAR_label: 'Redno',
  _layout_HOVER_label: 'Lebdenje',
  applyTo: 'Uporabi za {status}',
  isolate: 'Izoliraj',
  linkedToAnd: 'Povezano na {where1} in {where2}',
  linkedTo: 'Povezano na {where}',
  placeHolderTip: 'Izberite predlogo kartice.',
  showSelected: 'Pokaži izbiro',
  _widgetLabel: 'Kartica',
});