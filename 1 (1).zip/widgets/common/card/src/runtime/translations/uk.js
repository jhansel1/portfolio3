define({
  _layout_REGULAR_label: 'Звичайний',
  _layout_HOVER_label: 'Наведення',
  applyTo: 'Застосувати до {status}',
  isolate: 'Ізолювати',
  linkedToAnd: 'Приєднано до {where1} і {where2}',
  linkedTo: 'Приєднано до {where}',
  placeHolderTip: 'Виберіть шаблон картки.',
  showSelected: 'Показати вибірку',
  _widgetLabel: 'Картка',
});