define({
  _layout_REGULAR_label: 'Almindelig',
  _layout_HOVER_label: 'Hold over',
  applyTo: 'Ansøg til {status}',
  isolate: 'Isoler',
  linkedToAnd: 'Tilknyttet {where1} og {where2}',
  linkedTo: 'Tilknyttet {where}',
  placeHolderTip: 'Vælg en kortskabelon.',
  showSelected: 'Vis valg',
  _widgetLabel: 'Kort',
});