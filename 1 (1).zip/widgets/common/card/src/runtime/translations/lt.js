define({
  _layout_REGULAR_label: 'Įprastas',
  _layout_HOVER_label: 'Rodomas užvedus pele',
  applyTo: 'Taikyti {status}',
  isolate: 'Išskirti',
  linkedToAnd: 'Susieta su {where1} ir {where2}',
  linkedTo: 'Susieta su {where}',
  placeHolderTip: 'Pasirinkite kortelės šabloną.',
  showSelected: 'Rodyti pasirinkimą',
  _widgetLabel: 'Kortelė',
});