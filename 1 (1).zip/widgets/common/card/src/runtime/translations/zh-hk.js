define({
  _layout_REGULAR_label: '定期',
  _layout_HOVER_label: '懸停',
  applyTo: '套用到 {status}',
  isolate: '隔離',
  linkedToAnd: '已連結到 {where1} 和 {where2}',
  linkedTo: '已連結到 {where}',
  placeHolderTip: '請選擇卡片範本。',
  showSelected: '顯示選擇',
  _widgetLabel: '卡片',
});