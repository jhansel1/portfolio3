define({
  _layout_REGULAR_label: 'Szabályos',
  _layout_HOVER_label: 'Rámutatás',
  applyTo: 'Alkalmazás erre: {status}',
  isolate: 'Elszigetelés',
  linkedToAnd: 'Összekapcsolva ezzel: {where1} és {where2}',
  linkedTo: 'Összekapcsolva ezzel: {where}',
  placeHolderTip: 'Válasszon kártyasablont.',
  showSelected: 'Kijelölés megjelenítése',
  _widgetLabel: 'Kártya',
});