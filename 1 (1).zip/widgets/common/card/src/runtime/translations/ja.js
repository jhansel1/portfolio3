define({
  _layout_REGULAR_label: '標準',
  _layout_HOVER_label: 'ホバー',
  applyTo: '{status} に適用',
  isolate: '分離',
  linkedToAnd: '{where1} および {where2} へのリンク元',
  linkedTo: '{where} へのリンク元',
  placeHolderTip: 'カード テンプレートを選択してください。',
  showSelected: '選択セットの表示',
  _widgetLabel: 'カード',
});