define({
  _layout_REGULAR_label: 'Thường',
  _layout_HOVER_label: 'Di chuột qua',
  applyTo: 'Áp dụng cho {status}',
  isolate: 'Cách ly',
  linkedToAnd: 'Được liên kết với {where1} và {where2}',
  linkedTo: 'Được liên kết với {where}',
  placeHolderTip: 'Vui lòng lựa chọn một biểu mẫu thẻ.',
  showSelected: 'Hiển thị lựa chọn',
  _widgetLabel: 'Thẻ',
});