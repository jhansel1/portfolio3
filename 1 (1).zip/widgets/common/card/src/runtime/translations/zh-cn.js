define({
  _layout_REGULAR_label: '正则',
  _layout_HOVER_label: '悬停',
  applyTo: '应用于 {status}',
  isolate: '隔离',
  linkedToAnd: '链接到 {where1} 和 {where2}',
  linkedTo: '链接到 {where}',
  placeHolderTip: '请选择卡片模板。',
  showSelected: '显示所选项',
  _widgetLabel: '卡片',
});