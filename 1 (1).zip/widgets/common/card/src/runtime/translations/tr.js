define({
  _layout_REGULAR_label: 'Normal',
  _layout_HOVER_label: 'Üzerine gelindiğinde',
  applyTo: '{status} için geçerlidir',
  isolate: 'Ayrı tutun',
  linkedToAnd: '{where1} ve {where2} ile bağlantılıdır',
  linkedTo: '{where} ile bağlantılıdır',
  placeHolderTip: 'Lütfen bir kart şablonu seçin.',
  showSelected: 'Seçimi göster',
  _widgetLabel: 'Kart',
});