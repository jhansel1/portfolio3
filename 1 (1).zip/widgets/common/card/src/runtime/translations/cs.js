define({
  _layout_REGULAR_label: 'Běžné',
  _layout_HOVER_label: 'Přejetí myši',
  applyTo: 'Použít na {status}',
  isolate: 'Izolovat',
  linkedToAnd: 'Propojeno s {where1} a {where2}',
  linkedTo: 'Propojeno s {where}',
  placeHolderTip: 'Vyberte šablonu karty.',
  showSelected: 'Zobrazit výběr',
  _widgetLabel: 'Karta',
});