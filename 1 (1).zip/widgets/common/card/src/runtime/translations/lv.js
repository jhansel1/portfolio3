define({
  _layout_REGULAR_label: 'Parasta (neieslēgta)',
  _layout_HOVER_label: 'Ieslēgta',
  applyTo: 'Piemērot {status}',
  isolate: 'Izolēt',
  linkedToAnd: 'Saistīts ar {where1} un {where2}',
  linkedTo: 'Saistīts ar {where}',
  placeHolderTip: 'Lūdzu, izvēlieties kartītes veidni.',
  showSelected: 'Rādīt izvēli',
  _widgetLabel: 'Kartīte',
});