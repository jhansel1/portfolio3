define({
  _layout_REGULAR_label: 'Regularne',
  _layout_HOVER_label: 'Wskaż',
  applyTo: 'Zastosuj do {status}',
  isolate: 'Izoluj',
  linkedToAnd: 'Połączone z {where1} i {where2}',
  linkedTo: 'Połączone z {where}',
  placeHolderTip: 'Wybierz szablon karty.',
  showSelected: 'Pokaż wybór',
  _widgetLabel: 'Karta',
});