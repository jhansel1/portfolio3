define({
  _layout_REGULAR_label: 'Normal',
  _layout_HOVER_label: 'Trecere cu mouse-ul',
  applyTo: 'Aplicare la {status}',
  isolate: 'Izolare',
  linkedToAnd: 'Asociat cu {where1} și {where2}',
  linkedTo: 'Asociat cu {where}',
  placeHolderTip: 'Selectați un șablon de cartelă.',
  showSelected: 'Afişaţi selecţia',
  _widgetLabel: 'Cartelă',
});