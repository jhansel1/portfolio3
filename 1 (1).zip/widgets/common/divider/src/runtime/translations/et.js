define({
  _widgetLabel: 'Jaotaja',
});