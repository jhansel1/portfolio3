define({
  _widgetLabel: 'Osztó',
});