define({
  _widgetLabel: 'Delitelj',
});