define({
  _widgetLabel: 'Séparateur',
});