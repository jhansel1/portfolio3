define({
  _widgetLabel: 'Bộ chia',
});