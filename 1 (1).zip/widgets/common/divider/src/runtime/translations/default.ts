export default {
  _widgetLabel: 'Divider',
}