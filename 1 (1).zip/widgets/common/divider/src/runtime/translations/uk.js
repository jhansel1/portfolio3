define({
  _widgetLabel: 'Роздільник',
});