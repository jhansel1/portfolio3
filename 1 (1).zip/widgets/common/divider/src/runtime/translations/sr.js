define({
  _widgetLabel: 'Razdelnik',
});