define({
  _widgetLabel: '구분선',
});