define({
  _widgetLabel: 'מפריד',
});