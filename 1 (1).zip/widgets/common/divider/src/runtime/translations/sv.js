define({
  _widgetLabel: 'Avdelare',
});