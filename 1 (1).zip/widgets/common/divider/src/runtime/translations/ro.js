define({
  _widgetLabel: 'Divizor',
});