define({
  _widgetLabel: '区切り線',
});