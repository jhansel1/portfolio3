define({
  _widgetLabel: 'Sudalinimas',
});