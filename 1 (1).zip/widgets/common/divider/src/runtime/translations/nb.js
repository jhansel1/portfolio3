define({
  _widgetLabel: 'Skiller',
});