define({
  _widgetLabel: '分隔线',
});