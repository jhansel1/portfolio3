define({
  _widgetLabel: 'Divisore',
});