define({
  _widgetLabel: 'ตัวแบ่ง',
});