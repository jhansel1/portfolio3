define({
  _widgetLabel: 'Bölücü',
});