import WidgetInBuilder from './builder/widget';

export default { WidgetInBuilder };