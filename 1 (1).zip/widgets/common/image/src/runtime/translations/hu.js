define({
  _widgetLabel: 'Kép',
  imageChooseShape: 'Alakzat',
  imageCrop: 'Kivágás'
});