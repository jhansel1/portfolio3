define({
  _widgetLabel: 'Billede',
  imageChooseShape: 'Form',
  imageCrop: 'Beskær'
});