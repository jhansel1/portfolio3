define({
  _widgetLabel: '이미지',
  imageChooseShape: '모양',
  imageCrop: '자르기'
});