define({
  _widgetLabel: 'รูปภาพ',
  imageChooseShape: 'รูปร่าง',
  imageCrop: 'ครอบตัด'
});