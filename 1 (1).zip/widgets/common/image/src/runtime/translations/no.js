export default {
  _widgetLabel: 'Bilde',
  imageChooseShape: 'Form',
  imageCrop: 'Beskjær'
}