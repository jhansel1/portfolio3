define({
  _widgetLabel: 'Attēls',
  imageChooseShape: 'Forma',
  imageCrop: 'Apgriezt'
});