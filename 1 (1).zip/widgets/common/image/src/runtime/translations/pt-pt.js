define({
  _widgetLabel: 'Imagem',
  imageChooseShape: 'Forma',
  imageCrop: 'Cortar'
});