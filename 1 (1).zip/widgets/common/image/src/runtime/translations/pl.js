define({
  _widgetLabel: 'Obraz rastrowy',
  imageChooseShape: 'Kształt',
  imageCrop: 'Przytnij'
});