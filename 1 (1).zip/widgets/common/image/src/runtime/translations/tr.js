define({
  _widgetLabel: 'Görüntü',
  imageChooseShape: 'Şekil',
  imageCrop: 'Kes'
});