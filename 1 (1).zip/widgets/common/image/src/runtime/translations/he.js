define({
  _widgetLabel: 'תמונה',
  imageChooseShape: 'צורה',
  imageCrop: 'חיתוך'
});