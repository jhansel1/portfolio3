define({
  _widgetLabel: 'Image',
  imageChooseShape: 'Forme',
  imageCrop: 'Rogner'
});