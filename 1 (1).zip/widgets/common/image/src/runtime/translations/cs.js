define({
  _widgetLabel: 'Snímek',
  imageChooseShape: 'Tvar',
  imageCrop: 'Ořez'
});