define({
  _widgetLabel: 'Schaltfläche'
});