define({
  _widgetLabel: 'زر'
});