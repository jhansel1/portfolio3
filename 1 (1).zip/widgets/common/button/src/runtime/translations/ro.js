define({
  _widgetLabel: 'Buton'
});