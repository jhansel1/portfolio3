define({
  _widgetLabel: '버튼'
});