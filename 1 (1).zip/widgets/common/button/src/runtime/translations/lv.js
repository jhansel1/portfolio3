define({
  _widgetLabel: 'Poga'
});