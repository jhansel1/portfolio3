define({
  _widgetLabel: 'Bouton'
});