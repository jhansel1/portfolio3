define({
  _widgetLabel: 'ボタン'
});