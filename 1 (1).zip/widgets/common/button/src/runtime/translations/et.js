define({
  _widgetLabel: 'Nupp'
});