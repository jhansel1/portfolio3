define({
  _widgetLabel: 'Κουμπί'
});