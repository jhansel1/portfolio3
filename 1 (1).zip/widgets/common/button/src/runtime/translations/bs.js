define({
  _widgetLabel: 'Gumb'
});