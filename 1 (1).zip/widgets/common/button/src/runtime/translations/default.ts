export default {
  _widgetLabel: 'Button'
}