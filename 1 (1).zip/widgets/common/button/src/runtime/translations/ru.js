define({
  _widgetLabel: 'Кнопка'
});