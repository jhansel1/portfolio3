define({
  _widgetLabel: 'Tombol'
});