define({
  _widgetLabel: 'Botão'
});