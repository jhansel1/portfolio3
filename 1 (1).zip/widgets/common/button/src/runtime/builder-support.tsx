import { QuickStyle } from './builder/quick-style';

export default {
  QuickStyle
};