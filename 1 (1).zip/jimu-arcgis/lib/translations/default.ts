export default {
  layerIsNotSupported: 'This layer type is not supported.'
}
